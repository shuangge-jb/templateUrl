export default function(){
  require("src/app/business/database/controller/instanceDatabaseCtrl");
  require("src/app/business/redis/controller/instanceRedisCtrl");
  require("src/app/business/database/service/databaseService");
}

