define([],function(){
    return {};
});