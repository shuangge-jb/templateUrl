define([],function(){
    
    function serviceCtrl(){

    }
    angular.module('framework').controller('serviceCtrl',serviceCtrl);
});