define([], function() {
    const framework = angular.module('framework', []);
    return framework;
});