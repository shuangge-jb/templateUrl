define([], function() {
  return { name: "jb" };
});
