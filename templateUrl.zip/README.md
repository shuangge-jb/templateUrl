### DONE
#### 框架解耦
#### js加上哈希
#### 自动将打出来的包添加到index.html中
#### webpack.config.js中只导出一个对象，里面有3个entry

### TODO
#### mini-css-plugin不能自动把样式文件加到index.html中
#### i18n还没有做完
#### HMR没做完
#### 不具备懒加载能力，所有conroller，service要在bootstrap前执行
#### 没有分2种模式：直接调接口和本地mock
#### 尝试写一个引入图片的样式，通过打包将图片引入
#### 从代码层面，在require前把fixture去掉，不影响源码
#### 了解一下如何自定义插件和loader
#### 多个string-replace执行时会很慢，原因？（loader的原理）
#### 在webpack的配置文件中使用import等语法
#### 配置eslint

### 注
#### require引入的顺序没有要求
#### 业务包无需返回promise，直接放到function中即可
#### main.js中无需使用window.require businessAll.js，可通过自动引入businessAll.js实现（前提：不设置libraryTarget和library,只有一个config对象，不分多个对象来设置）